import React from 'react';

const UseSalesReturnHook = () => {
  return {};
};

export default UseSalesReturnHook;
