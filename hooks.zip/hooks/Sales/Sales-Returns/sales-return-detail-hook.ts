import React from 'react';

const UseSalesReturnDetailHook = () => {
  return {};
};

export default UseSalesReturnDetailHook;
